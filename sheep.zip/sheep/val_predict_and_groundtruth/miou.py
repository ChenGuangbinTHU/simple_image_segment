from PIL import Image
import numpy as np

def miou(predict, ground_truth):
	# ground_truth = Image.open(ground_truth)
	# predict = Image.open(predict).resize((ground_truth.shape[0], ground_truth.shape[1]))
	
	g = np.array(Image.open(ground_truth))[:, :, 0]
	print(g.shape)
	p = np.array(Image.open(predict).resize((g.shape[1],g.shape[0])))[:, :, 0]
	print(p.shape)
	# print(p>=254)
	p[p< 250] = 0
	p[p>=250] = 1
	u_cnt = 0
	i_cnt = 0
	for gg,pp in zip(g.ravel(), p.ravel()):
		if gg == 1 and pp == 1:
			i_cnt += 1
		if gg == 1 or pp == 1:
			u_cnt += 1
	print(i_cnt/u_cnt)
	# print(predict)

if __name__ == '__main__':
	miou('72.jpg','72.png')
